package com.application.myvideoplay;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

public class MainActivity2 extends AppCompatActivity {

    VideoView video_view;
    MediaController mediaControls;
    private String path;
    ImageView image_back;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        video_view=findViewById(R.id.video_view);
        image_back=findViewById(R.id.image_back);

        image_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        Intent intent=getIntent();
        path=intent.getStringExtra("url");

        if (mediaControls == null) {
            mediaControls = new MediaController(MainActivity2.this);
            mediaControls.setAnchorView(video_view);
        }
        video_view.setMediaController(mediaControls);
//       String uri=;
        video_view.setVideoPath(path);
        video_view.start();



    }
}