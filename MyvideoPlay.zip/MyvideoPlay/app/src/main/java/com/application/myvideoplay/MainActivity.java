package com.application.myvideoplay;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerview_list;
    ArrayList<ModelClass> arrayList = new ArrayList<>();
    ImageView image_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerview_list = findViewById(R.id.recyclerview_list);
        image_back=findViewById(R.id.image_back);

        image_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        arrayList.add(new ModelClass("http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4", "For Bigger Joyrides", "images/ForBiggerJoyrides.jpg"));
        arrayList.add(new ModelClass("http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "Big Buck Bunny", "images/BigBuckBunny.jpg"));
        arrayList.add(new ModelClass("http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4", "Elephant Dream", "images/ElephantsDream.jpg"));
        arrayList.add(new ModelClass("http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4", "For Bigger Blazes", "images/ForBiggerBlazes.jpg"));
        arrayList.add(new ModelClass("http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4", "For Bigger Escape", "images/ForBiggerEscapes.jpg"));
        arrayList.add(new ModelClass("http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4", "Volkswagen GTI Review", "images/VolkswagenGTIReview.jpg"));
        AdapterClass adapterClass = new AdapterClass(getApplicationContext(), arrayList);
        recyclerview_list.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerview_list.setAdapter(adapterClass);


    }
}